import parent
print(locals())
